from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Student
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Invalid credentials!")
    return render(request, 'login.html')

@login_required
def home(request):
    students = Student.objects.filter(teacher=request.user)
    return render(request, 'home.html', {'students': students})
@login_required
def add_student(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        subject = request.POST.get('subject')
        marks = request.POST.get('marks')
        
        
        if not all([name, subject, marks]):
            messages.error(request, "All fields are required!")
            return render(request, 'add_student.html')
        
        try:
            marks = int(marks)
        except ValueError:
            messages.error(request, "Marks must be a valid number!")
            return render(request, 'add_student.html')
        
        
        try:
            existing_student = Student.objects.get(
                name=name,
                subject=subject,
                teacher=request.user
            )
            
            existing_student.marks += marks  
            existing_student.save()
            messages.success(request, f"Added marks for {name} in {subject}. New total: {existing_student.marks}")
        except Student.DoesNotExist:
           
            Student.objects.create(
                name=name,
                subject=subject,
                marks=marks,
                teacher=request.user
            )
            messages.success(request, f"Added new student {name} for {subject} with marks {marks}")
        except Exception as e:
            messages.error(request, f"An error occurred: {str(e)}")
        
        return redirect('home')
    
    return render(request, 'add_student.html')

@login_required
def edit_student(request, student_id):
    try:
        student = Student.objects.get(id=student_id, teacher=request.user)
        if request.method == 'POST':
            student.name = request.POST.get('name')
            student.subject = request.POST.get('subject')
            marks = request.POST.get('marks')
            
            try:
                student.marks = int(marks)
                student.save()
                messages.success(request, "Student updated successfully!")
                return redirect('home')
            except ValueError:
                messages.error(request, "Marks must be a valid number!")
            
        return render(request, 'edit_student.html', {'student': student})
    except Student.DoesNotExist:
        messages.error(request, "Student not found or you don't have permission to edit.")
        return redirect('home')

@login_required
def delete_student(request, student_id):
    if request.method == 'POST':
        try:
            student = Student.objects.get(id=student_id, teacher=request.user)
            student.delete()
            messages.success(request, "Student deleted successfully!")
        except Student.DoesNotExist:
            messages.error(request, "Student not found or you don't have permission to delete.")
    return redirect('home')

def logout_view(request):
    logout(request)
    return redirect('login')